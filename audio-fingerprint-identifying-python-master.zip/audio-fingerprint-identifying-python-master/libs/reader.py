class BaseReader(object):
  def __init__(self, a):
    self.a = a

  def recognize(self):
    pass  # base class does nothing
