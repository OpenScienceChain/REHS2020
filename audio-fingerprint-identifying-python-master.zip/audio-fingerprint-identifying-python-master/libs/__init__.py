import matplotlib
# matplotlib.use('Agg')
matplotlib.use('TkAgg')

def x():
  print('XXX')
